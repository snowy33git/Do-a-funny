How to activate:
go to raw/doafunnylauncher
enjoy
How to stop
go to raw/dontdoafunny1
launch
go to raw/dontdoafunny2
launch
done